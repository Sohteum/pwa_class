import React from 'react';

const Comp = ({idx}) => {
  return (
    <p>
      컴포넌트 {idx}
    </p>
  );
};

export default Comp;