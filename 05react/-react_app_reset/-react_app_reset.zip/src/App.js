function App() {
  return (
    <>
    <h1>리액트 첫 시간입니다</h1>
    </>
  );
}

export default App;
