//배열 만들려고. 이름을 붙여돋됨 디폴트 뒤에 = 붙이고 

export default [
  {
    id: 0,
    title: '길동와 식사',
    date: '2023-05-05',
    time: '18:00',
    desc: "Lorem ipsum dolor sit amet consectetur"
  },
  {
    id: 1,
    title: '아무개랑 식사' ,
    date: '2023-02-05',
    time: '11:00',
    desc: "dipisicing elit."
  },
  {
    id: 2,
    title: '철수랑 영화',
    date: '2023-01-05',
    time: '15:00',
    desc: "dipisicing elit."
  },
]