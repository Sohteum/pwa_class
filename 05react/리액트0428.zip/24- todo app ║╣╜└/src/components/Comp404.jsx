import React from 'react';

const Comp404 = () => {
  return (
    <div>
      해당 주소는 존재하지 않습니다
    </div>
  );
};

export default Comp404;