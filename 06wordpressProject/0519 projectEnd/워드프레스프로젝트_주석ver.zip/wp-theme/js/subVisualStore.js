//여기서 객체를 만들어줄것.


const subVisualArr = [
  {
    title: 'about',
    desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit.Quas earum similique nisi nulla, neque rem sed deserunt officia libero, fuga optio quos deleniti porro atque natus quae aperiam! Assumenda, ratione.',
    imgPath: '/img/sub/sub01.jpg',
  },
  {
    title: 'biz',
    desc: 'Quaerat porro dolorum ut saepe, itaque alias! Corrupti qui incidunt minus culpa saepe dolor temporibus cumque quibusdam eius veniam, facilis, autem atque velit neque ut? Quam nesciunt magnam accusantium minus.',
    imgPath: '/img/sub/sub02.jpg',
  },
  {
    title: 'product',
    desc: 'Aliquam, laboriosam minima exercitationem unde facere est maxime ea sint quibusdam. Officia sequi, voluptatum qui vel vero perspiciatis hic reprehenderit doloremque debitis id ex iusto libero suscipit modi cumque neque!',
    imgPath: '/img/sub/sub03.jpg',
  },
  {
    title: 'online',
    desc: 'Velit aliquid similique, maxime repellendus excepturi odit et nobis fuga tempore eligendi. Temporibus non delectus iusto ratione. Maiores voluptatibus consequatur iure blanditiis facere soluta perspiciatis, asperiores perferendis fuga aperiam qui.',
    imgPath: '/img/sub/sub04.jpg',
  },
  {
    title: 'community',
    desc: 'Explicabo id alias ducimus odit possimus aliquid quasi autem impedit excepturi incidunt commodi sit magni, tempora reprehenderit debitis in. Quisquam veniam, ipsa pariatur earum vitae quia quo eos nesciunt magnam.',
    imgPath: '/img/sub/sub05.jpg',
  },
  {
    title: 'member',
    desc: 'In doloribus, alias aliquam ipsum minima dolorum dolorem odit eligendi cumque soluta commodi similique consectetur, saepe nam deleniti natus rerum illo error placeat voluptas dolor aliquid et. Nemo, pariatur est.',
    imgPath: '/img/sub/sub06.jpg',
  },
]




