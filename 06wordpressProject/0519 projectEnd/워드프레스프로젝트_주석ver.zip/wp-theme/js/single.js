$(function(){

  $('.snb>div>ul>li>ul>li.current-post-parent').parent().parent().show()//서브메뉴보여줄려궁
  
})