<footer>
  footer
</footer>
<!--site-footer -->
<?php wp_footer(); ?>
</body>
</html>