<?php get_header(); ?>

	<!--블로그 글 출력 시작-->
  본문
	<!--블로그 글 출력 끝-->

<?php get_footer(); ?>