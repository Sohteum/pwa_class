<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'sohteum1' );

/** MySQL database username */
define( 'DB_USER', 'sohteum1' );

/** MySQL database password */
define( 'DB_PASSWORD', 'Yongchoi1!' );

define('WP_HOME', 'http://sohteum1.dothome.co.kr');
define('WP_SITEURL','http://sohteum1.dothome.co.kr');

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'R5i;a8ovo^qrJ_NzAs@`m*38y#) jWbGgm:fpeg>*XC8hcCGHe~!I%7oFmm,4%P0' );
define( 'SECURE_AUTH_KEY',  '?*:t1L#+?IAj=(FlBn*QE#5>2X_>>*;fLHY2P|nwws)>7H+<#TeRS.x},~?qED-z' );
define( 'LOGGED_IN_KEY',    'vaess,+O{S&O7Oh))DOS %9(Omg*ik2Me4;DV2X<R(1_)27T:XkW#m`aH|7AGc*[' );
define( 'NONCE_KEY',        '1?QCW 1Bnr{5U]boW6Xm7`*Zy^~24@EmSMh(&X4VX@JQ2{N|Ia(&tSlF;GN0Y0z$' );
define( 'AUTH_SALT',        '[{5=khUbLLzvEF8Na,ET)O)>7nfISEMOuO+]/.-:kvv>_acyEs`4l`R>D1w</pIi' );
define( 'SECURE_AUTH_SALT', 'r!qA.c]TbA&4Fd;g3%w]4;-^C+Ih(@TQd/61wwj>JClCabJ^guRQ-L-b]LJpX`8C' );
define( 'LOGGED_IN_SALT',   ',#*c];(3v,,6XXN%5L,N>t[}}O$_Z$cnheO0doA`;5C]M;{t2jC]+YUe{J~y<_rd' );
define( 'NONCE_SALT',       'UW%cz~|Fg@3l*3EuhY`S[x[9EFDFg>kqI Yq%2wJIXj`LDl%c|x+tHjib*ukEvT,' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
