<svg viewBox="0 0 75 450">
	<path class="curve" d="M37.5,25c50,50-50,50,0,100s-50,50,0,100s-50,50,0,100s-49.1,50,0,100"/>
	<path class="progress" pathLength="1" d="M37.5,25c50,50-50,50,0,100s-50,50,0,100s-50,50,0,100s-49.1,50,0,100"/>
	<circle class="circle" cx="0" cy="0" r="17.7"/>
</svg>
