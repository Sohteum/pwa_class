<!-- 중첩구조가 아니어서 바로 a로 만든다 -->
<a href="1" class="link1">main</a>
<a href="2" class="link2">recent fly</a>
<a href="3" class="link3">service area</a>
<a href="4" class="link4">portfolio</a>
<a href="5" class="link5">inside</a>
<a href="6" class="link6">contact</a>