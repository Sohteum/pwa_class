<?php include "header.php" ?>
  
<main>
  <?php include "section1.php" ?>
  <?php include "shortcut.php" ?>
  <?php include "section2.php" ?>
  <?php include "section3.php" ?>
  <?php include "section4.php" ?>
  <?php include "section5.php" ?>
  <?php include "section6.php" ?>
</main>
<?php include "modal.php" ?>

<?php include "footer.php" ?>