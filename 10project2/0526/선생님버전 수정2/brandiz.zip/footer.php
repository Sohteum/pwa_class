<div class="footer-height"></div>
<footer>
  <div class="top">
    <h6>
      <?php include "img/svg/logo.php" ?>
      <?php include "img/svg/logo.php" ?>
      <img src="./img/common/logo_title.png" alt="">
    </h6>
  </div>
  <div class="bottom">
    <nav class="gnb fnb">
      <?php include "menu.php" ?>
    </nav>
    <p>COPYRIGHTⒸBRANDIZ.CO.KR ALL RIGHT RESERVED.</p>
  </div>
</footer>
</body>
</html>