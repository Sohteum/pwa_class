<div class="modal">
  <span class="loader"></span>
  <button class="close"><i class="fa-solid fa-circle-xmark"></i></button>
</div><!-- main의 형제 -->