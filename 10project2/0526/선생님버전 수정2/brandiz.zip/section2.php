<script src="./js/section2.js"></script>

<section class="section2">
<!-- <script src="js/particles.js"></script> -->
  <script src="js/app_particle_default.js"></script>
  <div id="particles-js"></div>

  <img class="bg" src="./img/section2/section2_bg.png" alt="">

  <figure class="carousel">
    <img class="dummy" src="./img/section2/seciton2_01.png" alt=""> <!-- 높이 때문에 -->

    <img class="img img1" src="./img/section2/seciton2_01.png" alt="">
    <img class="img img2" src="./img/section2/seciton2_02.png" alt="">
    <button class="prev"></button>
    <button class="next"></button>
  </figure>
</section>