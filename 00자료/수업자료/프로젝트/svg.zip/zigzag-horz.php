<svg viewBox="0 0 1700 75" preserveAspectRatio="none">
	<path pathLength="1" class="line" d="M0,12.5h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50	h50"/>
	<defs>
		<path class="zigzag" d="M1700,12.5l-50,50l-50-50l-50,50l-50-50l-50,50l-50-50l-50,50l-50-50l-50,50l-50-50l-50,50l-50-50l-50,50	l-50-50l-50,50l-50-50l-50,50l-50-50l-50,50l-50-50l-50,50l-50-50l-50,50l-50-50l-50,50l-50-50l-50,50l-50-50l-50,50l-50-50l-50,50 l-50-50l-50,50l-50-50"/>
		<path class="linecopy" d="M0,12.5h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50h50	h50"/>
	</defs>
</svg>
